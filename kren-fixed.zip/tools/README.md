Đặt file obfuscator vào đây, tên theo quy tắc: han-obfuscator-<obfuscator_version>.jar

Ví dụ: muốn dùng bản v12, đặt file "han-obfuscator-v12.jar" vào thư mục này,
rồi sửa dòng `obfuscator_version=v9` trong gradle.properties thành `obfuscator_version=v12`.

Chạy: ./gradlew obfuscate   (bước này không nằm trong task build mặc định)
