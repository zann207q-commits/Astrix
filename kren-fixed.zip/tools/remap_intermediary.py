#!/usr/bin/env python3
"""Remap Minecraft intermediary names (class_/method_/field_) in .java sources to Yarn names.

Usage: python remap_intermediary.py <yarn-v2.jar> <dir_or_file> [<dir_or_file> ...]
Missing paths are skipped with a warning.
"""
import re
import sys
import zipfile
from pathlib import Path


def load_mappings(jar_path):
    with zipfile.ZipFile(jar_path) as z:
        data = z.read("mappings/mappings.tiny").decode("utf-8").splitlines()
    header = data[0].split("\t")
    if header[0] != "tiny" or header[1] != "2":
        sys.exit("ERROR: expected tiny v2 mappings")
    classes, methods, fields = {}, {}, {}
    cur = None
    for line in data[1:]:
        if not line:
            continue
        indent = len(line) - len(line.lstrip("\t"))
        p = line.strip("\t").split("\t")
        if indent == 0 and p[0] == "c":
            cur = p
            if len(p) >= 3 and p[1] != p[2]:
                classes[p[1]] = p[2]
        elif indent == 1 and p[0] == "m" and len(p) >= 4:
            if p[2].startswith("method_") and p[3] != p[2] and p[3] != "<init>":
                methods[p[2]] = p[3]
        elif indent == 1 and p[0] == "f" and len(p) >= 4:
            if p[2].startswith("field_") and p[3] != p[2]:
                fields[p[2]] = p[3]
    return classes, methods, fields


def build_replacer(classes, methods, fields):
    simple = {}
    for inter, named in classes.items():
        s_inter = re.split(r"[/$]", inter)[-1]
        s_named = re.split(r"[/$]", named)[-1]
        if s_inter.startswith("class_"):
            simple[s_inter] = s_named

    fq_re = re.compile(r"net\.minecraft\.class_\d+(?:[.$]class_\d+)*")
    tok_re = re.compile(r"\b(class_\d+|method_\d+|field_\d+)\b")

    def fq_sub(m):
        text = m.group(0)
        parts = re.split(r"[.$]", text)
        key = "/".join(parts[:3]) + "".join("$" + x for x in parts[3:])
        named = classes.get(key)
        if not named:
            return text
        return named.replace("/", ".").replace("$", ".")

    def tok_sub(m):
        t = m.group(1)
        if t.startswith("class_"):
            return simple.get(t, t)
        if t.startswith("method_"):
            return methods.get(t, t)
        return fields.get(t, t)

    def remap(src):
        src = fq_re.sub(fq_sub, src)
        return tok_re.sub(tok_sub, src)

    return remap


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    jar = sys.argv[1]
    classes, methods, fields = load_mappings(jar)
    print(f"Loaded {len(classes)} classes, {len(methods)} methods, {len(fields)} fields")
    remap = build_replacer(classes, methods, fields)
    changed = total = 0
    for arg in sys.argv[2:]:
        p = Path(arg)
        if not p.exists():
            print(f"WARN: {arg} not found, skipping")
            continue
        files = [p] if p.is_file() else sorted(p.rglob("*.java"))
        for f in files:
            total += 1
            old = f.read_text(encoding="utf-8")
            new = remap(old)
            if new != old:
                f.write_text(new, encoding="utf-8")
                changed += 1
                print(f"remapped {f}")
    print(f"Done: {changed}/{total} files changed")


if __name__ == "__main__":
    main()
